package com.example.dataentry;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class splash extends AppCompatActivity {
    private database dbHelper;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        Button btnEnter = (Button) findViewById(R.id.buttonEnter);
        Button btnList = (Button) findViewById(R.id.buttonList);
        Button btnDelete = (Button) findViewById(R.id.buttonDel);
        /*
         * Handle the event generated when the user clicks the "Enter data"
         * button
         */
        btnEnter.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                displayFormEntryScreen(); // call method defined later in the
                // program
            }
        });

        /*
         * Handle the event generated when the user clicks the "List records"
         * button
         */

        btnList.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                displayListScreen(); // call method defined later in the program
            }
        });

        /*
         * Handle the event generated when the user clicks the "Delete all Records"
         * button
         */

        btnDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                deleteUnits(); // call method defined later in the program
            }
        });

        // Get ready to access the database later if we want to delete records
        dbHelper = new database(this);
    }

    private void displayFormEntryScreen() {
        startActivity(new Intent(this, MainActivity.class));
    }

    private void displayListScreen() {
        startActivity(new Intent(this, ListUnits.class));
    }

    private void deleteUnits() {
        // Create and display the Alert dialog
        new AlertDialog.Builder(this)
                .setMessage(
                        "Are you sure you want to delete all storage units?")
                .setNegativeButton("No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,	int which) {
                                // do nothing - it will just close when clicked
                            }
                        })
                .setPositiveButton("Yes",
                        new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog,	int which) {
                                // save the details entered if "Save" button clicked
                                dbHelper.deleteAllData();
                                popupToast("All the units are gone!");
                            }
                        }).show();

    }
    /* Utility method created to display a popup "toast" alert */
    private void popupToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

}
