package com.example.dataentry;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

//creating the database in which the details are stored
public class database extends SQLiteOpenHelper {
    public static final  String DATABASE_NAME = "myStorage2.db";
    public static final  String TABLE_NAME2 = "storage_table";
    public static final  String t2_ID = "ID";
    public static final  String t2_storageType = "storageType";
    public static final  String t2_dimension = "dimension";
    public static final  String t2_date = "date";
    public static final  String t2_storageFeatures = "storageFeatures";
    public static final  String t2_monthlyRent = "monthlyRent";
    public static final  String t2_notes = "notes";
    public static final  String t2_username = "username";


    public database(Context context)  {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME2 + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, storageType TEXT, dimension TEXT, date TEXT, storageFeatures TEXT, monthlyRent TEXT, notes TEXT, username TEXT)");

    }


    //persistence
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME2);
//
        onCreate(db);

    }

    //the following pulls the data which the user entered and inserts it into the database
    public boolean insertData(String storageType, String dimension, String date, String storageFeatures, String monthlyRent, String notes, String username){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(t2_storageType, storageType);
        contentValues.put(t2_dimension, dimension);
        contentValues.put(t2_date, date);
        contentValues.put(t2_storageFeatures, storageFeatures);
        contentValues.put(t2_monthlyRent, monthlyRent);
        contentValues.put(t2_notes, notes);
        contentValues.put(t2_username, username);

        long result = db.insert(TABLE_NAME2, null, contentValues );

        if (result == -1){

            return false;
        }else {
            return true;
        }
    }

    public Cursor getAllData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from " + TABLE_NAME2, null);
        return res;
    }

    public Cursor deleteAllData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor del = db.rawQuery(" delete from " + TABLE_NAME2, null);
        return del;
    }



}
