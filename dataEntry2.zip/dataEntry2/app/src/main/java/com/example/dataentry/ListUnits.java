package com.example.dataentry;

import android.app.ListActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.SimpleCursorAdapter;

public class ListUnits extends ListActivity {
    private database dbHelper;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        dbHelper = new database(this);
        displayData();

    }
    private void displayData() {
        // TODO Auto-generated method stub
        Cursor results = dbHelper.getAllData();

        String[] columnNames ={database.t2_ID, database.t2_storageType, database.t2_dimension};
        int[] displayNames={R.id.TextName, R.id.TextDOB, R.id.TextEmail};

        SimpleCursorAdapter records = new SimpleCursorAdapter(this, R.layout.list_units_row,
                results, columnNames, displayNames);
        setListAdapter(records);
    }

    /* Display the menu. Note the menu is defined in list_menu.xml */
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_list, menu);
        return true;
    }

    /* Process the user's selection from the menu */
    public boolean onOptionsItemSelected(MenuItem item) {
        // Find which menu item was selected
        switch (item.getItemId()) {
            case R.id.itemHome: // Home item was selected
                /*
                 * Easiest way to go back is to simulate the back button being pressed.
                 * See http://myandroidnote.blogspot.com/2011/04/go-back-to-previous-activity.html
                 */
                super.onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}