package com.example.dataentry;

import android.app.DatePickerDialog;
import android.app.SearchManager;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements
        DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener{


//declaring the variables and objects being used further in the code
    Button submit, date, editView;
    EditText editStore, editdimension, editStoreFeature, editMonthlyRent, editNotes, editusernam;
    DatePicker editDate;
    database myDb;

    int day, month,year,hour,minute;
    int dayFinal, monthFinal,yearFinal,hourFinal,minuteFinal;

    TextView AM;

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        MenuInflater inflater = getMenuInflater();
//        inflater.inflate(R.menu.menu_item, menu);
//
//        SearchManager searchManager =
//                (SearchManager) getSystemService(Context.SEARCH_SERVICE);
//        SearchView searchView =
//                (SearchView) menu.findItem(R.id.search).getActionView();
//        searchView.setSearchableInfo(
//                searchManager.getSearchableInfo(getComponentName()));
//
//        return true;
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDb = new database(this);
        submit = findViewById(R.id.button);

        //these are the input boxes for each field
        //as well as their IDs
        editStore = findViewById(R.id.storageType);
        editdimension = findViewById(R.id.dimension);
        date = findViewById(R.id.date);
        editStoreFeature = findViewById(R.id.storageFeatures);
        editMonthlyRent = findViewById(R.id.monthlyRent);
        editNotes = findViewById(R.id.monthlyRent);
        editusernam = findViewById(R.id.reporter);
        editView = findViewById(R.id.btnview);

        //the functions (such as viewing and deleting records, the date picker etc) being used further in the code
        getsubmit();
        date();
        viewAll();

    }

    //the submit button passes the information in the form to the database
    public void getsubmit(){
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String storeName = editStore.getText().toString();
                final String dimension = editdimension.getText().toString();
                final String storeFeature = editStoreFeature.getText().toString();
                final String monthlyRent = editMonthlyRent.getText().toString();
                final String notes = editNotes.getText().toString();
                final String usernam = editusernam.getText().toString();
                final String date1 = date.getText().toString();


                //here is the validation for each field, ensuring the form
                //does not allow the user to submit any empty fields
                if (storeName.isEmpty()){
                    Toast.makeText(getApplicationContext(), "you must enter a storage type", Toast.LENGTH_LONG).show();
                }else if(dimension.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "you must enter a unit size", Toast.LENGTH_LONG).show();
                }else if(date1.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "please select a date and time", Toast.LENGTH_LONG).show();
                }else if(storeFeature.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "you must enter a unit size", Toast.LENGTH_LONG).show();
                }else if(monthlyRent.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "you must indicate the monthly rental cost (ZMW)", Toast.LENGTH_LONG).show();
                }else if(usernam.isEmpty()){
                    Toast.makeText(getApplicationContext(), "you must enter your (the reporter's) username", Toast.LENGTH_LONG).show();
//                } dimension.isEmpty() | date1.isEmpty() | storeFeature.isEmpty() | monthlyRent.isEmpty() | notes.isEmpty() | usernam.isEmpty()){
//                    Toast.makeText(getApplicationContext(), "Whoops! These fields can't be empty", Toast.LENGTH_LONG).show();
                }else if (usernam.length() < 6) {
                    Toast.makeText(getApplicationContext(), "Username cannot be less than 6 Characters", Toast.LENGTH_LONG).show();

                }else {
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Confirm your information \n")
                            .setMessage("Great! Are you sure you want to save your details?")
                            .setNeutralButton("Back", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            })
                            .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    new AlertDialog.Builder(MainActivity.this)
                                            .setTitle("Storage details")
                                            .setMessage(
                                            " Details entered:\n " + "Storage Type: " + storeName + "\n" +
                                                    "Dimensions: " + dimension +" square metres" + "\n" +
                                                    "Date: " + date1 + "\n" +
                                                    "Features: " + storeFeature + "\n" +
                                                    "Monthly Rent: " + monthlyRent + "\n" +
                                                        "Notes: " + notes + "\n" +
                                                        "Reporter: " + usernam)
                                            .setNeutralButton("Back", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {

                                                }

                                            })
                                            .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {

//
                                                     String storeName = editStore.getText().toString();
                                                     String dimension = editdimension.getText().toString();
                                                     String date1 = date.getText().toString();
                                                     String storeFeature = editStoreFeature.getText().toString();
                                                     String monthlyRent = editMonthlyRent.getText().toString();
                                                     String notes = editNotes.getText().toString();
                                                     String usernam = editusernam.getText().toString();



                                                    boolean isInserted = myDb.insertData(storeName, dimension, date1,storeFeature,monthlyRent, notes, usernam);

                                                    if (isInserted == true) {
                                                        showMessage("Great job!", "Your details have been entered successfully");
                                                    } else
                                                        Toast.makeText(MainActivity.this, "Details not entered", Toast.LENGTH_LONG).show();
                                                }
                                            }).show();
                                }
                            }).show();
                }

            }
        });
    }

    //here, the user is able to view all the units stored within the application
    public void viewAll() {

        editView.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor res = myDb.getAllData();
                        if (res.getCount() == 0) {
                            //show message indicating no records exist
                            Toast.makeText(getApplicationContext(), "No storage units currently exist", Toast.LENGTH_LONG).show();
                            return;
                        }
                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext()) {
                            buffer.append("ID: " + res.getString(0) + "\n");
                            buffer.append("Storage Type: " + res.getString(1) + "\n");
                            buffer.append("Dimensions: " + res.getString(2) + " metres squared" + "\n");
                            buffer.append("Date and Time: " + res.getString(3) + "\n");
                            buffer.append("Features: " + res.getString(4) + "\n");
                            buffer.append("Monthly Rent: K" + res.getString(5) + "\n");
                            buffer.append("Notes: " + res.getString(6) + "\n\n");
                        }

                        // show all data
                        showMessage("Units", buffer.toString());
                    }
                }
        );
    }

    //the following is the date and time picker
    public void date(){

        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this, MainActivity.this, year,month,day);
                datePickerDialog.show();



            }
        });
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

        yearFinal = year;
        monthFinal = month;
        dayFinal = dayOfMonth;


        Calendar calendar = Calendar.getInstance();
        hour = calendar.get(Calendar.HOUR_OF_DAY);
        minute = calendar.get(Calendar.MONTH);
        TimePickerDialog timePickerDialog = new TimePickerDialog(MainActivity.this, MainActivity.this,hour,minute, DateFormat.is24HourFormat(this));
        timePickerDialog.show();


    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

        hourFinal = hourOfDay;
        minuteFinal = minute;

//        tv_result.setText( "Date: " + monthFinal+ "/" +
//                "/" +  dayFinal  + "/" +
//                yearFinal + "  " + "Time: " +
//                "Time: " + hourFinal + " : " +
//                minuteFinal  + "\n");

        date.setText( monthFinal+ "/" +
                "/" +  dayFinal  + "/" +
                yearFinal + "  "  +
                "Time: " + hourFinal + " : " +
                minuteFinal  + "\n");

    }

    //here the information is displayed back to the user and they are able to confirm if it is correct
    public void showMessage(String title, String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();

    }


}
